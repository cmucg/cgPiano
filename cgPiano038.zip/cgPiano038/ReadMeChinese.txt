
陈式简易键盘琴(Chen's Simplified Piano, cgPiano)是 中国医科大学 陈光 设计并 编程实现，是MIT许可证(MIT License)免费开源软件。下载地址：https://github.com/cmucg/cgPiano 

双击 cgPiano035Chinese.html 浏览器会打开一个新网页：陈式简易键盘琴。但它并不使用网络。

打字起始位置 手指下8个键 ASDF JKL; 是 中音 1234 567i
向上一排 对应位置的8个键 QWER UIOP 是 高音 1234 567i
向下一排 对应位置的8个键 ZXCV M,./ 是 低音 1234 567i
提前按下Shift，以上各键 升高半音

回车键：停止发音。引号键 亦可 停止发音

空格键：根据最后一个音符键 自动弹奏一个和弦音。再次按 空格键 自动弹奏下一个和弦音。
g键、h键：类似空格键，只是 起始的 和弦音 不同。

上下左右键：升降调，每按一次 升高或降低 一个 半音。转动 鼠标轮 亦可 升降调。

界面中 默认勾选 手指抬起后声音持续，这有利于 声音的连续性。也可以 取消勾选，以实现跳跃感。
界面中 亦可勾选 同时按下多个键，发多个音用于和弦：适用于 熟练后 自由 弹奏 和弦。

代码中299-305行 可改变 自动和弦的设置。

本软件 亦为 展示 一种新的 编程范式 PPO (Procedural Programmed Objects) that is a simplification of OOP and prototype-based programming. 比 现有的 编程范式 OOP(面向对象编程)、基于原型的编程(prototype-based programming)更加 简单、高效。

本软件 同时 展示 一种新的 超轻量级 JavaScript编程框架 PPO.js 以 更简单 更透明的方式 实现了 JavaScript代码和网页元素的复用。

Tone.js 是用到的库，本文件夹中已有，您也可以从以下网址下载：
https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.39/Tone.js

This project uses Tone.js, which is licensed under the MIT License.
Tone.js Copyright (c) 2014-2020, Yotam Mann
License: https://github.com/Tonejs/Tone.js/blob/dev/LICENSE.md
