This software piano (Chen's Simplified Piano, cgPiano) is designed and programmed by Dr.ChenGuang of China Medical University, under the MIT License, free to download from https://github.com/cmucg/cgPiano 

Double click cgPiano035English.html the piano web page will be opened in web browser 

Starting position for typing: The eight keys under the fingers, ASDF JKL;  are middle 1234 567i 

The eight keys in the corresponding positions on the row above, QWER UIOP  are high   1234 567i 

The eight keys in the corresponding positions on the row below, ZXCV M,./  are low    1234 567i 

Shift-key raises 1 semitone to the keys.

Enter-key : Stop all sound. The quotation-mark-key can also stop all sound. 

Space-bar : Automatically play one of the chord-notes according to the last note-key. Press again to play the next chord-note. The keys G and H also work this way, but begin at a lower note. 

Change-pitch: Rotate mouse-wheel or left right up down key to set how-many semitones to be changed. 

The lines 299-305 in source-code can be used to set auto-chord.

This piano-software also aims to show a new programming-paradigm PPO (Procedural Programmed Objects) that is a simplification of OOP and prototype-based programming. 

This piano-software also aims to show a super-light-weight JavaScript programming-framework PPO.js that realized reusing of self-defined-doms and JavaScripts in an easy and clear way, thus suitable for small projects. 


Tone.js is the function-library for music downloaded from
https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.39/Tone.js

This project uses Tone.js, which is licensed under the MIT License.
Tone.js Copyright (c) 2014-2020, Yotam Mann
License: https://github.com/Tonejs/Tone.js/blob/dev/LICENSE.md
