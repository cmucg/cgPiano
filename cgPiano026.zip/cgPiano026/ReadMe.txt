This soft piano (CG piano) is designed and programmed by Dr.ChenGuang of China Medical University, under the MIT License.

Double click cgPiano026.html the piano web page will be opened in web browser 

Starting position for typing: The eight keys under the fingers, ASDF JKL;  are middle 1234 567i 

The eight keys in the corresponding positions on the row above, QWER UIOP  are high   1234 567i 

The eight keys in the corresponding positions on the row below, ZXCV M,./  are low    1234 567i 

Space-bar: Stop the sound.


The check box is checked to make the sound continue after releasing a key until you play another note or press the space-bar.
You can also un-check it to make the sound stop as soon as you release a key.

Change-pitch: click in the input-box and rotate mouse wheel to set how-many semitones.

Tone.js is the function-library for music downloaded from
https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.39/Tone.js

This project uses Tone.js, which is licensed under the MIT License.
Tone.js Copyright (c) 2014-2020, Yotam Mann
License: https://github.com/Tonejs/Tone.js/blob/dev/LICENSE.md
